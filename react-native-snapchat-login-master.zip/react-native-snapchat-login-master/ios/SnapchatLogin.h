#import <React/RCTBridgeModule.h>

@interface SnapchatLogin : NSObject <RCTBridgeModule>

@end
